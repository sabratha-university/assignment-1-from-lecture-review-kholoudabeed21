# الفرق بين Overloading و Overriding في الكود

في كود SimpleLocation.java عندي نوعين من المفاهيم في البرمجة الكائنية:



# أولاً: Overloading (زيادة التحميل)

- معناها إن عندي أكثر من دالة بنفس الاسم داخل نفس الكلاس، لكن تختلف في عدد أو نوع المعاملات (parameters).
- هذا يسمح باستدعاء نفس الاسم لأكثر من غرض بطريقة مرنة.
- في كودنا، عندي دالتين بنفس الاسم distance:

`java
public double distance(SimpleLocation other) { ... }

public double distance(double lat, double lon) { ... }

هنا الاثنتين بنفس الاسم، لكن:

الأولى تستقبل كائن (Object) من نوع SimpleLocation.

الثانية تستقبل قيم مباشرة (latitude, longitude).


هذا هو Overloading لأنه تم في نفس الكلاس وبنفس الاسم لكن معاملات مختلفة.

يتم تحديد أي دالة تُستخدم أثناء وقت الترجمة (Compile Time).

#ثانياً: Overriding (إعادة التعريف)

معناها إن الكلاس الحالي يعيد تعريف دالة موجودة مسبقًا في الكلاس الأب (Superclass).

في كودنا، عندي دالة:


@Override
public String toString() {
    return "SimpleLocation{" + "latitude=" + latitude + ", longitude=" + longitude + '}';
}

هذه الدالة اسمها toString() وهي أصلًا موجودة في الكلاس الأب Object (كل كلاس في Java يرث منه).

استخدمنا الكلمة المفتاحية @Override للدلالة أننا نعيد تعريفها بطريقة تناسب كلاسنا.

هذا هو Overriding لأنه نفس الاسم ونفس المعاملات لكن تنفيذ مختلف.

#الفرق بين Overloading و Overriding

المقارنة Overloading Overriding

المكان داخل نفس الكلاس بين كلاس أب وكلاس ابن
التغيير في عدد أو نوع المعاملات في تنفيذ الدالة نفسها
وقت التحديد أثناء الترجمة (Compile Time) أثناء التشغيل (Run Time)
الغرض توفير مرونة في استخدام نفس الاسم تعديل سلوك موروث من الأب
مثال من الكود distance() (دالتين مختلفتين في المعاملات) toString() (أعدنا تعريفها)