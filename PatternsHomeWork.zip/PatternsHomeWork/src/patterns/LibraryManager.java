package patterns;

import java.util.*;

public class LibraryManager {
    private static LibraryManager instance;
    private Map<String, Book> books;
    private Section rootSection;

    private LibraryManager() {
        books = new HashMap<>();
        rootSection = new Section("المكتبة الرئيسية");
    }

    public static synchronized LibraryManager getInstance() {
        if (instance == null) {
            instance = new LibraryManager();
        }
        return instance;
    }

    public void addBook(Book book) {
        books.put(book.getId(), book);
    }

    public Book getBook(String id) {
        return books.get(id);
    }

    public boolean removeBook(String bookId) {
        Book book = books.remove(bookId);
        return book != null;
    }

    public Collection<Book> getAllBooks() {
        return books.values();
    }

    public Section getRootSection() {
        return rootSection;
    }

    public void printCatalog() {
        System.out.println("\n=== فهرس المكتبة ===");
        rootSection.display(0);
    }

    public List<String> searchInCatalog(String query) {
        List<String> results = new ArrayList<>();
        searchInSection(rootSection, query.toLowerCase(), results);
        return results;
    }

    private void searchInSection(Section section, String query, List<String> results) {
        if (section.getName().toLowerCase().contains(query)) {
            results.add("القسم: " + section.getName());
        }
        
        for (LibraryItem item : section.getChildren()) {
            if (item instanceof Book) {
                Book book = (Book) item;
                if (book.toString().toLowerCase().contains(query)) {
                    results.add(" " + book.toString());
                }
            } else if (item instanceof Section) {
                searchInSection((Section) item, query, results);
            }
        }
    }
}