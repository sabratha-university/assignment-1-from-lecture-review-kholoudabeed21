package patterns;

public interface Command {
    boolean execute();
}