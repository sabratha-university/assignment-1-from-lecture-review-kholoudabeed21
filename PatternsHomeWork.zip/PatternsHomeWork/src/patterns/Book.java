package patterns;

public class Book implements LibraryItem {
    private String id;
    private String title;
    private String author;
    private boolean available;

    public Book(String id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.available = true;
    }

    // Getters المطلوبة
    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public boolean isAvailable() {
        return available;
    }

    // Setters (اختيارية)
    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public boolean borrow() {
        if (available) {
            available = false;
            return true;
        }
        return false;
    }

    public void returnBook() {
        available = true;
    }

    @Override
    public void display(int indent) {
        String pad = " ".repeat(Math.max(0, indent));
        System.out.println(pad + "- Book: " + title + " by " + author + " [" + id + "]"
                + (available ? " (Available)" : " (Borrowed)"));
    }

    @Override
    public String toString() {
        return title + " by " + author + " [" + id + "]" + (available ? " (Available)" : " (Borrowed)");
    }
}