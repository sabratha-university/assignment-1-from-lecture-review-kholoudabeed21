package patterns;

public interface LibraryItem {
    void display(int indent);
}