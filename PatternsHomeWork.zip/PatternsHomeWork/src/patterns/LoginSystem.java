package patterns;

import java.util.Scanner;

public class LoginSystem {
    private static String currentUser;
    private static String currentRole;
    
    public static boolean login(Scanner scanner) {
        System.out.println("\n" + "=".repeat(30) + " تسجيل الدخول " + "=".repeat(30));
        System.out.println("المستخدمون المتاحون:");
        System.out.println("1. admin (أمين مكتبة)");
        System.out.println("2. user (مستخدم عادي)");
        System.out.println("=".repeat(50));
        System.out.print("اختر رقم المستخدم: ");
        
        String choice = scanner.nextLine().trim();
        
        switch (choice) {
            case "1":
                currentUser = "admin";
                currentRole = "admin";
                System.out.println("\nمرحباً أمين المكتبة!");
                return true;
            case "2":
                currentUser = "user";
                currentRole = "user";
                System.out.println("\nمرحباً أيها المستخدم!");
                return true;
            default:
                System.out.println("\nاختيار غير صحيح!");
                return false;
        }
    }
    
    public static void logout() {
        System.out.println("\nتم تسجيل الخروج. مع السلامة " + currentUser);
        currentUser = null;
        currentRole = null;
    }
    
    public static String getCurrentUser() {
        return currentUser;
    }
    
    public static String getCurrentRole() {
        return currentRole;
    }
    
    public static boolean isAdmin() {
        return "admin".equals(currentRole);
    }
}