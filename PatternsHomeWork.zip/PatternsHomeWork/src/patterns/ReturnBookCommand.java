package patterns;

public class ReturnBookCommand implements Command {
    private LibraryManager manager;
    private String bookId;

    public ReturnBookCommand(LibraryManager manager, String bookId) {
        this.manager = manager;
        this.bookId = bookId;
    }

    @Override
    public boolean execute() {
        Book b = manager.getBook(bookId);
        if (b == null) {
            System.out.println("Book not found: " + bookId);
            return false;
        }
        b.returnBook();
        System.out.println("Returned: " + b);
        return true;
    }
}