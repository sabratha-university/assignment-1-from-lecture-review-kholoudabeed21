
package patterns;


public class DeleteBookCommand implements Command {
    private LibraryManager manager;
    private String bookId;
    private Book deletedBook;
    private Section parentSection;

    public DeleteBookCommand(LibraryManager manager, String bookId) {
        this.manager = manager;
        this.bookId = bookId;
    }

    @Override
    public boolean execute() {
        Book book = manager.getBook(bookId);
        if (book == null) {
            System.out.println(" الكتاب غير موجود: " + bookId);
            return false;
        }
        
        this.deletedBook = book;
        
        // البحث عن القسم الأب
        this.parentSection = findParentSection(manager.getRootSection(), book);
        
        // حذف الكتاب من القسم
        if (parentSection != null) {
            parentSection.remove(book);
            System.out.println("تم حذف الكتاب من قسم: " + parentSection.getName());
        }
        
        // حذف الكتاب من LibraryManager
        boolean removed = manager.removeBook(bookId);
        
        if (removed) {
            System.out.println(" تم حذف الكتاب: " + book.getTitle() + " [" + book.getId() + "]");
            return true;
        } else {
            System.out.println(" فشل في حذف الكتاب!");
            return false;
        }
    }
    
    private Section findParentSection(Section section, Book targetBook) {
        // ابحث في الأبناء المباشرين
        for (LibraryItem item : section.getChildren()) {
            if (item == targetBook) {
                return section;
            }
        }
        
        // ابحث في الأقسام الفرعية
        for (LibraryItem item : section.getChildren()) {
            if (item instanceof Section) {
                Section result = findParentSection((Section) item, targetBook);
                if (result != null) return result;
            }
        }
        return null;
    }
}