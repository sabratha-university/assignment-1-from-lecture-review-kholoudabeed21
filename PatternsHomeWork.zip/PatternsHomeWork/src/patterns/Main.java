
package patterns;

import java.util.*;

public class Main {
    private static LibraryManager manager;
    private static Invoker invoker;
    private static Scanner scanner;
    private static List<Section> sections;
    
    private static final String ADMIN_PASSWORD = "1234";
    
    public static void main(String[] args) {
        scanner = new Scanner(System.in);
        initializeSystem();
        
        while (true) {
            try {
                System.out.println("\n" + "=".repeat(40));
                System.out.println("       نظام إدارة المكتبة");
                System.out.println("=".repeat(40));
                System.out.println("1. أمين المكتبة");
                System.out.println("2. مستخدم عادي");
                System.out.println("3. عرض الفهرس");
                System.out.println("4. خروج");
                System.out.println("=".repeat(40));
                System.out.print("اختر رقم الخيار: ");
                
                String choice = scanner.nextLine().trim();
                
                switch (choice) {
                    case "1":
                        verifyAdminPassword();
                        break;
                    case "2":
                        showUserMenu();
                        break;
                    case "3":
                        displayCatalog();
                        break;
                    case "4":
                        System.out.println("\nشكراً لاستخدامك النظام. إلى اللقاء!");
                        scanner.close();
                        System.exit(0);
                    default:
                        System.out.println("\nاختيار غير صحيح!");
                }
            } catch (Exception e) {
                System.out.println("خطأ: " + e.getMessage());
            }
        }
    }
    
    private static void initializeSystem() {
        try {
            manager = LibraryManager.getInstance();
            invoker = new Invoker();
            sections = new ArrayList<>();
            
            if (manager.getAllBooks().isEmpty()) {
                setupDefaultData();
            }
        } catch (Exception e) {
            System.out.println("خطأ في التهيئة: " + e.getMessage());
        }
    }
    
    private static void setupDefaultData() {
        try {
            Section fiction = new Section("أدب");
            Section cs = new Section("علوم الحاسب");
            Section history = new Section("تاريخ");
            
            sections.add(fiction);
            sections.add(cs);
            sections.add(history);
            
            manager.getRootSection().add(fiction);
            manager.getRootSection().add(cs);
            manager.getRootSection().add(history);
            
            Book b1 = new Book("B001", "الخيميائي", "باولو كويلو");
            Book b2 = new Book("B002", "Clean Code", "Robert C. Martin");
            Book b3 = new Book("B003", "تاريخ الحضارات", "ول ديورانت");
            
            invoker.executeCommand(new AddBookCommand(manager, b1, fiction));
            invoker.executeCommand(new AddBookCommand(manager, b2, cs));
            invoker.executeCommand(new AddBookCommand(manager, b3, history));
            
            System.out.println("تم تحميل البيانات الافتراضية.");
        } catch (Exception e) {
            System.out.println("خطأ في تحميل البيانات: " + e.getMessage());
        }
    }
    
    private static void verifyAdminPassword() {
        System.out.println("\n" + "=".repeat(40));
        System.out.println("       تسجيل دخول أمين المكتبة");
        System.out.println("=".repeat(40));
        System.out.print("أدخل كلمة المرور: ");
        
        String password = scanner.nextLine().trim();
        
        if (password.equals(ADMIN_PASSWORD)) {
            System.out.println("\nتم تسجيل الدخول بنجاح!");


showAdminMenu();
        } else {
            System.out.println("\nكلمة المرور غير صحيحة!");
        }
    }
    
    private static void showAdminMenu() {
        while (true) {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       قائمة أمين المكتبة");
            System.out.println("=".repeat(40));
            System.out.println("1. عرض الفهرس");
            System.out.println("2. إضافة كتاب جديد");
            System.out.println("3. حذف كتاب");
            System.out.println("4. استعارة كتاب");
            System.out.println("5. إرجاع كتاب");
            System.out.println("6. عرض جميع الكتب");
            System.out.println("7. عرض الكتب المتاحة فقط");
            System.out.println("8. البحث في المكتبة (كتب + أقسام)");
            System.out.println("9. إنشاء قسم جديد");
            System.out.println("10. حذف قسم");
            System.out.println("11. عرض إحصائيات المكتبة");
            System.out.println("12. العودة للقائمة الرئيسية");
            System.out.println("=".repeat(40));
            System.out.print("اختر رقم الخيار: ");
            
            String choice = scanner.nextLine().trim();
            
            switch (choice) {
                case "1":
                    displayCatalog();
                    break;
                case "2":
                    addNewBook();
                    break;
                case "3":
                    deleteBook();
                    break;
                case "4":
                    borrowBook();
                    break;
                case "5":
                    returnBook();
                    break;
                case "6":
                    displayAllBooks();
                    break;
                case "7":
                    displayAvailableBooks();
                    break;
                case "8":
                    searchInCatalog();
                    break;
                case "9":
                    createNewSection();
                    break;
                case "10":
                    deleteSection();
                    break;
                case "11":
                    showStatistics();
                    break;
                case "12":
                    return;
                default:
                    System.out.println("\nاختيار غير صحيح!");
            }
        }
    }
    
    private static void showUserMenu() {
        while (true) {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       قائمة المستخدم العادي");
            System.out.println("=".repeat(40));
            System.out.println("1. عرض الفهرس");
            System.out.println("2. استعارة كتاب");
            System.out.println("3. إرجاع كتاب");
            System.out.println("4. البحث في المكتبة (كتب + أقسام)");
            System.out.println("5. عرض الكتب المتاحة فقط");
            System.out.println("6. عرض إحصائيات المكتبة");
            System.out.println("7. العودة للقائمة الرئيسية");
            System.out.println("=".repeat(40));
            System.out.print("اختر رقم الخيار: ");
            
            String choice = scanner.nextLine().trim();
            
            switch (choice) {
                case "1":
                    displayCatalog();
                    break;
                case "2":
                    borrowBook();
                    break;
                case "3":
                    returnBook();
                    break;
                case "4":
                    searchInCatalog();
                    break;
                case "5":
                    displayAvailableBooks();
                    break;
                case "6":
                    showStatistics();
                    break;
                case "7":


return;
                default:
                    System.out.println("\nاختيار غير صحيح!");
            }
        }
    }
    
    private static void displayCatalog() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       فهرس المكتبة");
            System.out.println("=".repeat(40));
            manager.printCatalog();
        } catch (Exception e) {
            System.out.println("خطأ في عرض الفهرس: " + e.getMessage());
        }
    }
    
    private static void addNewBook() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       إضافة كتاب جديد");
            System.out.println("=".repeat(40));
            
            System.out.print("أدخل معرف الكتاب (ID): ");
            String id = scanner.nextLine().trim();
            
            if (manager.getBook(id) != null) {
                System.out.println("\nكتاب بهذا المعرف موجود مسبقاً!");
                return;
            }
            
            System.out.print("أدخل عنوان الكتاب: ");
            String title = scanner.nextLine().trim();
            
            if (title.isEmpty()) {
                System.out.println("\nيجب إدخال عنوان الكتاب!");
                return;
            }
            
            System.out.print("أدخل اسم المؤلف: ");
            String author = scanner.nextLine().trim();
            
            if (author.isEmpty()) {
                System.out.println("\nيجب إدخال اسم المؤلف!");
                return;
            }
            
            System.out.println("\nاختر القسم:");
            for (int i = 0; i < sections.size(); i++) {
                System.out.println((i + 1) + ". " + sections.get(i).getName());
            }
            System.out.println("0. إضافة إلى القسم الرئيسي");
            
            System.out.print("اختيارك: ");
            String sectionChoiceStr = scanner.nextLine().trim();
            
            try {
                int sectionChoice = Integer.parseInt(sectionChoiceStr);
                Section selectedSection = null;
                
                if (sectionChoice > 0 && sectionChoice <= sections.size()) {
                    selectedSection = sections.get(sectionChoice - 1);
                } else if (sectionChoice == 0) {
                    selectedSection = manager.getRootSection();
                } else {
                    System.out.println("اختيار غير صحيح، سيتم إضافة الكتاب إلى القسم الرئيسي.");
                    selectedSection = manager.getRootSection();
                }
                
                Book newBook = new Book(id, title, author);
                AddBookCommand addCmd = new AddBookCommand(manager, newBook, selectedSection);
                invoker.executeCommand(addCmd);
                
            } catch (NumberFormatException e) {
                System.out.println("يجب إدخال رقم صحيح!");
            }
            
        } catch (Exception e) {
            System.out.println("خطأ في إضافة الكتاب: " + e.getMessage());
        }
    }
    
    private static void deleteBook() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       حذف كتاب");
            System.out.println("=".repeat(40));
            
            Collection<Book> allBooks = manager.getAllBooks();
            if (allBooks.isEmpty()) {
                System.out.println("لا توجد كتب في المكتبة!");
                return;
            }
            
            System.out.println("قائمة الكتب المتاحة للحذف:");
            System.out.println("-".repeat(40));
            
            List<Book> booksList = new ArrayList<>(allBooks);
            for (int i = 0; i < booksList.size(); i++) {
                Book book = booksList.get(i);


System.out.printf("%d. %s - %s [%s]%n", 
                    i + 1, 
                    book.getTitle(), 
                    book.getAuthor(), 
                    book.getId());
            }
            
            System.out.print("\nأدخل رقم الكتاب للحذف (1-" + booksList.size() + "): ");
            String choiceStr = scanner.nextLine().trim();
            
            try {
                int choice = Integer.parseInt(choiceStr);
                if (choice < 1 || choice > booksList.size()) {
                    System.out.println("رقم غير صحيح!");
                    return;
                }
                
                Book bookToDelete = booksList.get(choice - 1);
                
                System.out.println("\nمعلومات الكتاب المختار:");
                System.out.println("العنوان: " + bookToDelete.getTitle());
                System.out.println("المؤلف: " + bookToDelete.getAuthor());
                System.out.println("المعرف: " + bookToDelete.getId());
                System.out.println("الحالة: " + (bookToDelete.isAvailable() ? "متاح" : "مستعار"));
                
                System.out.print("\nهل أنت متأكد من حذف هذا الكتاب؟ (نعم/لا): ");
                String confirm = scanner.nextLine().trim().toLowerCase();
                
                if (confirm.equals("نعم") || confirm.equals("y")  ||  confirm.equals("yes")) {
                    DeleteBookCommand deleteCmd = new DeleteBookCommand(manager, bookToDelete.getId());
                    invoker.executeCommand(deleteCmd);
                } else {
                    System.out.println("تم إلغاء الحذف.");
                }
            } catch (NumberFormatException e) {
                System.out.println("يجب إدخال رقم صحيح!");
            }
        } catch (Exception e) {
            System.out.println("خطأ في حذف الكتاب: " + e.getMessage());
        }
    }
    
    private static void borrowBook() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       استعارة كتاب");
            System.out.println("=".repeat(40));
            
            System.out.print("أدخل معرف الكتاب: ");
            String bookId = scanner.nextLine().trim();
            
            BorrowBookCommand borrowCmd = new BorrowBookCommand(manager, bookId);
            invoker.executeCommand(borrowCmd);
        } catch (Exception e) {
            System.out.println("خطأ في استعارة الكتاب: " + e.getMessage());
        }
    }
    
    private static void returnBook() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       إرجاع كتاب");
            System.out.println("=".repeat(40));
            
            System.out.print("أدخل معرف الكتاب: ");
            String bookId = scanner.nextLine().trim();
            
            ReturnBookCommand returnCmd = new ReturnBookCommand(manager, bookId);
            invoker.executeCommand(returnCmd);
        } catch (Exception e) {
            System.out.println("خطأ في إرجاع الكتاب: " + e.getMessage());
        }
    }
    
    private static void displayAllBooks() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       جميع الكتب");
            System.out.println("=".repeat(40));
            
            Collection<Book> allBooks = manager.getAllBooks();
            
            if (allBooks.isEmpty()) {
                System.out.println("لا توجد كتب في المكتبة!");
                return;
            }
            
            int availableCount = 0;
            int borrowedCount = 0;
            
            System.out.println("\nقائمة جميع الكتب:");
            for (Book book : allBooks) {
                System.out.println("  - " + book);
                if (book.isAvailable()) {

availableCount++;
                } else {
                    borrowedCount++;
                }
            }
            
            System.out.println("\nالإحصائيات:");
            System.out.println("  إجمالي الكتب: " + allBooks.size());
            System.out.println("  الكتب المتاحة: " + availableCount);
            System.out.println("  الكتب المستعارة: " + borrowedCount);
            
        } catch (Exception e) {
            System.out.println("خطأ في عرض الكتب: " + e.getMessage());
        }
    }
    
    private static void displayAvailableBooks() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       الكتب المتاحة فقط");
            System.out.println("=".repeat(40));
            
            Collection<Book> allBooks = manager.getAllBooks();
            List<Book> availableBooks = new ArrayList<>();
            
            for (Book book : allBooks) {
                if (book.isAvailable()) {
                    availableBooks.add(book);
                }
            }
            
            if (availableBooks.isEmpty()) {
                System.out.println("لا توجد كتب متاحة حالياً!");
            } else {
                System.out.println("الكتب المتاحة (" + availableBooks.size() + " كتاب):");
                for (Book book : availableBooks) {
                    System.out.println("  - " + book);
                }
            }
        } catch (Exception e) {
            System.out.println("خطأ في عرض الكتب المتاحة: " + e.getMessage());
        }
    }
    
    private static void createNewSection() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       إنشاء قسم جديد");
            System.out.println("=".repeat(40));
            
            System.out.print("أدخل اسم القسم الجديد: ");
            String sectionName = scanner.nextLine().trim();
            
            if (sectionName.isEmpty()) {
                System.out.println("يجب إدخال اسم القسم!");
                return;
            }
            
            Section newSection = new Section(sectionName);
            sections.add(newSection);
            manager.getRootSection().add(newSection);
            
            System.out.println("تم إنشاء القسم الجديد: " + sectionName);
            System.out.println("يمكنك الآن إضافة كتب إلى هذا القسم.");
            
        } catch (Exception e) {
            System.out.println("خطأ في إنشاء القسم: " + e.getMessage());
        }
    }
    
    private static void deleteSection() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       حذف قسم");
            System.out.println("=".repeat(40));
            
            if (sections.isEmpty()) {
                System.out.println("لا توجد أقسام في المكتبة!");
                return;
            }
            
            System.out.println("قائمة الأقسام:");
            System.out.println("-".repeat(40));
            
            for (int i = 0; i < sections.size(); i++) {
                Section section = sections.get(i);
                int bookCount = countBooksInSection(section);
                System.out.printf("%d. %s (%d كتاب)%n", 
                    i + 1, 
                    section.getName(), 
                    bookCount);
            }
            
            System.out.print("\nاختر رقم القسم للحذف (1-" + sections.size() + "): ");
            String choiceStr = scanner.nextLine().trim();
            
            try {
                int choice = Integer.parseInt(choiceStr);
                if (choice < 1 || choice > sections.size()) {
                    System.out.println("رقم غير صحيح!");
                    return;
                }


Section sectionToDelete = sections.get(choice - 1);
                int bookCount = countBooksInSection(sectionToDelete);
                
                System.out.println("\nمعلومات القسم المختار:");
                System.out.println("اسم القسم: " + sectionToDelete.getName());
                System.out.println("عدد الكتب فيه: " + bookCount);
                
                if (bookCount > 0) {
                    System.out.println("  تحذير: هذا القسم يحتوي على " + bookCount + " كتاب!");
                    System.out.println("سيتم حذف جميع الكتب داخل هذا القسم!");
                }
                
                System.out.print("\nهل أنت متأكد من حذف هذا القسم؟ (نعم/لا): ");
                String confirm = scanner.nextLine().trim().toLowerCase();
                
                if (confirm.equals("نعم") || confirm.equals("y") || confirm.equals("yes")) {
                    DeleteSectionCommand deleteCmd = new DeleteSectionCommand(manager, sectionToDelete.getName());
                    invoker.executeCommand(deleteCmd);
                    
                    sections.remove(choice - 1);
                    System.out.println("تم تحديث قائمة الأقسام.");
                } else {
                    System.out.println("تم إلغاء الحذف.");
                }
            } catch (NumberFormatException e) {
                System.out.println("يجب إدخال رقم صحيح!");
            }
        } catch (Exception e) {
            System.out.println("خطأ في حذف القسم: " + e.getMessage());
        }
    }
    
    private static int countBooksInSection(Section section) {
        int count = 0;
        for (LibraryItem item : section.getChildren()) {
            if (item instanceof Book) {
                count++;
            } else if (item instanceof Section) {
                count += countBooksInSection((Section) item);
            }
        }
        return count;
    }
    
    private static void searchInCatalog() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       البحث في المكتبة");
            System.out.println("=".repeat(40));
            System.out.println("يمكنك البحث عن:");
            System.out.println("- اسم الكتاب");
            System.out.println("- اسم المؤلف");
            System.out.println("- معرف الكتاب");
            System.out.println("- اسم القسم");
            System.out.println("- حالة الكتاب (متاح/مستعار)");
            System.out.println("=".repeat(40));
            
            System.out.print("أدخل كلمة للبحث: ");
            String query = scanner.nextLine().trim().toLowerCase();
            
            if (query.isEmpty()) {
                System.out.println("يجب إدخال كلمة للبحث!");
                return;
            }
            
            List<String> results = manager.searchInCatalog(query);
            
            if (results.isEmpty()) {
                System.out.println("\nلم يتم العثور على نتائج تطابق البحث: '" + query + "'");
            } else {
                System.out.println("\nنتائج البحث (" + results.size() + " نتيجة):");
                for (String result : results) {
                    System.out.println("  " + result);
                }
            }
        } catch (Exception e) {
            System.out.println("خطأ في البحث: " + e.getMessage());
        }
    }
    
    private static void showStatistics() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("       إحصائيات المكتبة");
            System.out.println("=".repeat(40));
            
            Collection<Book> allBooks = manager.getAllBooks();
            
            int totalBooks = allBooks.size();
            int availableBooks = 0;
            int borrowedBooks = 0;


for (Book book : allBooks) {
                if (book.isAvailable()) {
                    availableBooks++;
                } else {
                    borrowedBooks++;
                }
            }
            
            int totalSections = sections.size();
            
            System.out.println(" إحصائيات عامة:");
            System.out.println("  إجمالي الكتب: " + totalBooks + " كتاب");
            System.out.println("  الكتب المتاحة: " + availableBooks + " كتاب");
            System.out.println("  الكتب المستعارة: " + borrowedBooks + " كتاب");
            System.out.println("  عدد الأقسام: " + totalSections + " قسم");
            
            if (totalBooks > 0) {
                double availablePercentage = (availableBooks * 100.0) / totalBooks;
                System.out.printf("  نسبة الكتب المتاحة: %.1f%%\n", availablePercentage);
            }
            
            if (totalSections > 0) {
                System.out.println("\n📂 إحصائيات الأقسام:");
                for (Section section : sections) {
                    int booksInSection = countBooksInSection(section);
                    System.out.println("  - " + section.getName() + ": " + booksInSection + " كتاب");
                }
            }
            
            System.out.println("\n إحصائيات النظام:");
            System.out.println("  عدد الأوامر المنفذة: " + invoker.historySize() + " أمر");
            
        } catch (Exception e) {
            System.out.println("خطأ في عرض الإحصائيات: " + e.getMessage());
        }
    }
}