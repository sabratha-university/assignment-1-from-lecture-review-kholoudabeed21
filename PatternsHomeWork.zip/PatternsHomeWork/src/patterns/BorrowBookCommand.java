package patterns;

public class BorrowBookCommand implements Command {
    private LibraryManager manager;
    private String bookId;

    public BorrowBookCommand(LibraryManager manager, String bookId) {
        this.manager = manager;
        this.bookId = bookId;
    }

    @Override
    public boolean execute() {
        Book b = manager.getBook(bookId);
        if (b == null) {
            System.out.println("Book not found: " + bookId);
            return false;
        }
        if (b.borrow()) {
            System.out.println("Borrowed: " + b);
            return true;
        } else {
            System.out.println("Cannot borrow, not available: " + b);
            return false;
        }
    }
}