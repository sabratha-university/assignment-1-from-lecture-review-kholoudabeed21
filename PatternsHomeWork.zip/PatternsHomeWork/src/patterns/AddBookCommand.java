package patterns;

public class AddBookCommand implements Command {
    private LibraryManager manager;
    private Book book;
    private Section targetSection;

    public AddBookCommand(LibraryManager manager, Book book, Section targetSection) {
        this.manager = manager;
        this.book = book;
        this.targetSection = targetSection;
    }

    @Override
    public boolean execute() {
        if (manager.getBook(book.getId()) != null) {
            System.out.println("Book with id " + book.getId() + " already exists.");
            return false;
        }
        manager.addBook(book);
        if (targetSection != null) {
            targetSection.add(book);
        } else {
            manager.getRootSection().add(book);
        }
        System.out.println("Added book: " + book);
        return true;
    }
}