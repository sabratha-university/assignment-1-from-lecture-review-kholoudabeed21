package patterns;

public class DeleteSectionCommand implements Command {
    private LibraryManager manager;
    private String sectionName;

    public DeleteSectionCommand(LibraryManager manager, String sectionName) {
        this.manager = manager;
        this.sectionName = sectionName;
    }

    @Override
    public boolean execute() {
        // البحث عن القسم في الهيكل
        Section root = manager.getRootSection();
        Section sectionToDelete = findSectionByName(root, sectionName);
        
        if (sectionToDelete == null) {
            System.out.println("❌ القسم غير موجود: " + sectionName);
            return false;
        }
        
        // حذف جميع الكتب في القسم أولاً
        deleteBooksInSection(sectionToDelete);
        
        // حذف القسم نفسه
        boolean removed = removeSectionFromParent(root, sectionToDelete);
        
        if (removed) {
            System.out.println("✅ تم حذف قسم: " + sectionName);
            return true;
        } else {
            System.out.println("❌ فشل في حذف القسم!");
            return false;
        }
    }
    
    private Section findSectionByName(Section current, String targetName) {
        if (current.getName().equals(targetName)) {
            return current;
        }
        
        for (LibraryItem item : current.getChildren()) {
            if (item instanceof Section) {
                Section found = findSectionByName((Section) item, targetName);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }
    
    private void deleteBooksInSection(Section section) {
        for (LibraryItem item : section.getChildren()) {
            if (item instanceof Book) {
                Book book = (Book) item;
                manager.removeBook(book.getId());
            } else if (item instanceof Section) {
                deleteBooksInSection((Section) item);
            }
        }
    }
    
    private boolean removeSectionFromParent(Section parent, Section sectionToDelete) {
        for (LibraryItem item : parent.getChildren()) {
            if (item == sectionToDelete) {
                parent.getChildren().remove(item);
                return true;
            } else if (item instanceof Section) {
                boolean removed = removeSectionFromParent((Section) item, sectionToDelete);
                if (removed) return true;
            }
        }
        return false;
    }
}