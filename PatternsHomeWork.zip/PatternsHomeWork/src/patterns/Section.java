package patterns;

import java.util.ArrayList;
import java.util.List;

public class Section implements LibraryItem {
    private String name;
    private List<LibraryItem> children;

    public Section(String name) {
        this.name = name;
        this.children = new ArrayList<>();
    }

    public void add(LibraryItem item) {
        children.add(item);
    }

    public void remove(LibraryItem item) {
        children.remove(item);
    }

    // ✅ إضافة دالة getName()
    public String getName() {
        return name;
    }

    public List<LibraryItem> getChildren() {
        return children;
    }

    @Override
    public void display(int indent) {
        String pad = " ".repeat(indent);
        System.out.println(pad + "> قسم: " + name);
        for (LibraryItem item : children) {
            item.display(indent + 4);
        }
    }
    
    @Override
    public String toString() {
        return name;
    }
}