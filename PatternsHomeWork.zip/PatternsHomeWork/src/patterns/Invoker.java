package patterns;
import java.util.Stack;

public class Invoker {
    private Stack<Command> history;

    public Invoker() {
        history = new Stack<>();
    }

    public void executeCommand(Command cmd) {
        try {
            boolean ok = cmd.execute();
            if (ok) {
                history.push(cmd);
            }
        } catch (Exception e) {
            System.out.println("❌ خطأ في تنفيذ الأمر: " + e.getMessage());
        }
    }

    public int historySize() {
        return history.size();
    }
}